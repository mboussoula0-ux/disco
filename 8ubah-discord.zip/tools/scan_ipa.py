#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scan_ipa.py - read-only static scan of a decrypted .ipa (pure python, no packages, works on Windows with `py`).
Lists ObjC class names, ObjC selectors and React-Native export signatures that contain your keywords,
straight from the Mach-O sections (this is what ktool failed to produce).

  py tools\\scan_ipa.py "Discord.ipa" voice audio chat input compose krisp
  -> writes scan-result.txt next to the ipa
"""
import sys, os, re, struct, zipfile, plistlib


def sections(data):
    """yield (segname, sectname, offset, size) for a thin arm64 Mach-O"""
    if struct.unpack_from('<I', data, 0)[0] != 0xFEEDFACF:
        return
    ncmds = struct.unpack_from('<I', data, 16)[0]
    off = 32
    for _ in range(ncmds):
        cmd, size = struct.unpack_from('<II', data, off)
        if cmd == 0x19:
            seg = data[off + 8:off + 24].split(b'\0')[0].decode()
            nsects = struct.unpack_from('<I', data, off + 64)[0]
            so = off + 72
            for _s in range(nsects):
                sect = data[so:so + 16].split(b'\0')[0].decode()
                o, = struct.unpack_from('<I', data, so + 48)
                sz, = struct.unpack_from('<Q', data, so + 40)
                yield seg, sect, o, sz
                so += 80
        off += size


def cstrings(data, off, size):
    return [s.decode('latin1') for s in data[off:off + size].split(b'\0') if s]


def main():
    if len(sys.argv) < 3:
        sys.exit('usage: py tools\\scan_ipa.py "Discord.ipa" keyword [keyword ...]')
    ipa = sys.argv[1]
    kws = [k.lower() for k in sys.argv[2:]]
    z = zipfile.ZipFile(ipa)
    apps = sorted({n.split('/')[1] for n in z.namelist() if n.startswith('Payload/') and n.split('/')[1].endswith('.app')})
    root = 'Payload/%s/' % apps[0]
    exe = plistlib.loads(z.read(root + 'Info.plist'))['CFBundleExecutable']
    print('reading', root + exe)
    data = z.read(root + exe)
    classes, methods, cstr = [], [], []
    for seg, sect, o, sz in sections(data):
        if sect == '__objc_classname':
            classes = cstrings(data, o, sz)
        elif sect == '__objc_methname':
            methods = cstrings(data, o, sz)
        elif sect == '__cstring':
            cstr = cstrings(data, o, sz)
    print('classes %d  selectors %d  cstrings %d' % (len(classes), len(methods), len(cstr)))

    def hit(s):
        l = s.lower()
        return any(k in l for k in kws)
    rn = [s for s in cstr if re.match(r'^[A-Za-z_][A-Za-z0-9_]* ?:? ?\(', s) and ' : (' in s or ' :(' in s]
    out = ['keywords: ' + ', '.join(kws), '']
    out.append('===== ObjC classes (%d)' % len([c for c in classes if hit(c)]))
    out += sorted(c for c in classes if hit(c))
    out.append('')
    out.append('===== ObjC selectors (%d)' % len([m for m in methods if hit(m)]))
    out += sorted(m for m in methods if hit(m))[:3000]
    out.append('')
    out.append('===== React-Native export signatures (%d)' % len([r for r in rn if hit(r)]))
    out += sorted(r for r in rn if hit(r))
    out.append('')
    out.append('===== other strings (first 1500)')
    out += [s[:200] for s in cstr if hit(s) and s not in rn][:1500]
    dst = os.path.join(os.path.dirname(os.path.abspath(ipa)), 'scan-result.txt')
    open(dst, 'w', encoding='utf-8').write('\n'.join(out))
    print('done ->', dst)


if __name__ == '__main__':
    main()
