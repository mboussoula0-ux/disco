#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_ipa.py - injects the 8ubah dylib into a decrypted Discord .ipa (pure python, no extra packages).

  py tools\\build_ipa.py "C:\\path\\Discord.ipa" "C:\\path\\8ubahDiscord.dylib"
  py tools\\build_ipa.py                      (looks for the newest *.ipa and 8ubahDiscord.dylib next to this script / in the project folder)

Output: <name>-8ubah.ipa next to the input .ipa. Install it with Sideloadly (it re-signs everything).
What it does: copies the dylib to Payload/<App>.app/Frameworks/, adds one LC_LOAD_DYLIB command to the main
executable (there is ~100 KB of free header space in the Discord binary), writes a fresh zip that keeps every
file's permissions. It does not touch anything else (existing tweaks such as BTLoader stay as they are).
"""
import sys, os, struct, zipfile, plistlib, glob, shutil

DYLIB_NAME = '8ubahDiscord.dylib'
LC_LOAD_DYLIB = 0xC
LC_SEGMENT_64 = 0x19


def patch_slice(buf, base):
    """buf: bytearray, base: offset of the thin Mach-O inside buf. returns (changed, message)"""
    magic = struct.unpack_from('<I', buf, base)[0]
    if magic != 0xFEEDFACF:
        return False, 'not a 64-bit little-endian Mach-O (magic %#x)' % magic
    ncmds, sizeofcmds = struct.unpack_from('<II', buf, base + 16)
    off = base + 32
    min_sect = None
    for _ in range(ncmds):
        cmd, size = struct.unpack_from('<II', buf, off)
        if cmd == LC_LOAD_DYLIB:
            name_off = struct.unpack_from('<I', buf, off + 8)[0]
            name = bytes(buf[off + name_off: off + size]).split(b'\0')[0].decode('utf-8', 'replace')
            if name.endswith(DYLIB_NAME):
                return False, 'already injected (%s)' % name
        if cmd == LC_SEGMENT_64:
            nsects = struct.unpack_from('<I', buf, off + 64)[0]
            so = off + 72
            for _s in range(nsects):
                o = struct.unpack_from('<I', buf, so + 48)[0]
                if o and (min_sect is None or o < min_sect):
                    min_sect = o
                so += 80
        off += size
    cmds_end = base + 32 + sizeofcmds
    path = ('@executable_path/Frameworks/' + DYLIB_NAME).encode() + b'\0'
    size = (24 + len(path) + 7) & ~7
    limit = base + (min_sect if min_sect else 0)
    if not min_sect or cmds_end + size > limit:
        return False, 'no free space in the Mach-O header for a new load command'
    cmd = struct.pack('<IIIIII', LC_LOAD_DYLIB, size, 24, 2, 0x10000, 0x10000) + path
    cmd += b'\0' * (size - len(cmd))
    buf[cmds_end:cmds_end + size] = cmd
    struct.pack_into('<II', buf, base + 16, ncmds + 1, sizeofcmds + size)
    return True, 'added LC_LOAD_DYLIB (%d bytes, %d bytes of header space left)' % (size, limit - cmds_end - size)


def patch_macho(data):
    buf = bytearray(data)
    magic_be = struct.unpack_from('>I', buf, 0)[0]
    if magic_be == 0xCAFEBABE:                      # fat binary: patch every 64-bit arm slice
        n = struct.unpack_from('>I', buf, 4)[0]
        res = []
        for i in range(n):
            cpu, sub, off, size, align = struct.unpack_from('>iiIII', buf, 8 + i * 20)
            res.append(patch_slice(buf, off))
        ok = any(r[0] for r in res)
        return bytes(buf), ok, '; '.join(r[1] for r in res)
    ok, msg = patch_slice(buf, 0)
    return bytes(buf), ok, msg


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    proj = os.path.dirname(here)
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    ipa = args[0] if args else None
    dylib = args[1] if len(args) > 1 else None
    if not ipa:
        c = sorted(glob.glob(os.path.join(os.getcwd(), '*.ipa')) + glob.glob(os.path.join(proj, '*.ipa')), key=os.path.getmtime, reverse=True)
        c = [x for x in c if not x.endswith('-8ubah.ipa')]
        ipa = c[0] if c else None
    if not dylib:
        for d in (os.getcwd(), proj, here):
            p = os.path.join(d, DYLIB_NAME)
            if os.path.isfile(p):
                dylib = p
                break
    if not ipa or not os.path.isfile(ipa):
        sys.exit('IPA not found. Usage: py tools\\build_ipa.py "Discord.ipa" "%s"' % DYLIB_NAME)
    if not dylib or not os.path.isfile(dylib):
        sys.exit('%s not found. Download it from the GitHub Actions artifact and pass its path as the 2nd argument.' % DYLIB_NAME)
    out = os.path.splitext(ipa)[0] + '-8ubah.ipa'
    print('IPA   :', ipa)
    print('DYLIB :', dylib)
    with zipfile.ZipFile(ipa) as zin:
        names = zin.namelist()
        apps = sorted({n.split('/')[1] for n in names if n.startswith('Payload/') and n.split('/')[1].endswith('.app')})
        if not apps:
            sys.exit('No Payload/*.app inside the IPA.')
        app = apps[0]
        root = 'Payload/%s/' % app
        plist = plistlib.loads(zin.read(root + 'Info.plist'))
        exe = plist['CFBundleExecutable']
        print('App   : %s  (%s %s)  executable=%s' % (app, plist.get('CFBundleShortVersionString'), plist.get('CFBundleVersion'), exe))
        exe_path = root + exe
        dy_path = root + 'Frameworks/' + DYLIB_NAME
        with open(dylib, 'rb') as f:
            dy_bytes = f.read()
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zout:
            patched = False
            for info in zin.infolist():
                if info.filename == dy_path:
                    continue                                  # replaced below
                data = zin.read(info.filename)
                if info.filename == exe_path:
                    data, ok, msg = patch_macho(data)
                    print('Mach-O:', msg)
                    if not ok and 'already injected' not in msg:
                        sys.exit('Injection failed: ' + msg)
                    patched = True
                ni = zipfile.ZipInfo(info.filename, info.date_time)
                ni.compress_type = zipfile.ZIP_STORED if info.is_dir() else zipfile.ZIP_DEFLATED
                ni.external_attr = info.external_attr
                ni.create_system = info.create_system
                zout.writestr(ni, data)
            if not patched:
                sys.exit('Main executable %s not found in the IPA.' % exe_path)
            di = zipfile.ZipInfo(dy_path, (2026, 1, 1, 0, 0, 0))
            di.compress_type = zipfile.ZIP_DEFLATED
            di.external_attr = (0o100755 << 16)
            di.create_system = 3
            zout.writestr(di, dy_bytes)
    print('DONE  :', out, '(%.1f MB)' % (os.path.getsize(out) / 1048576.0))
    print('Install it with Sideloadly.')


if __name__ == '__main__':
    main()
